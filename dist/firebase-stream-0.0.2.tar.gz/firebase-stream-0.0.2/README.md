## Firebase Stream Handler

This Python package was designed to provide an easy-to-use wrapper for the firebase-admin API in order to retrieve live changes to the Firebase DB.

* Use Firebase-Admin
* Formats requests with a parameter (DEBUG) to display live output
* More features to be added later on